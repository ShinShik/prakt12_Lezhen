import kotlinx.coroutines.*
import kotlin.random.Random

class num1 {
    var summ = 0
    var repeat = 0
    suspend fun start() = coroutineScope{
        try {
            println("Введите на сколько дней вы хотите оставить активной вашу ферму")
            repeat = readln().toInt()
            launch{farm_bit()}
            for (i in 1..repeat){
                println("$i день")
                delay(2000L)
            }
        }
        catch (a: Exception){
            println("Введён некорректный символ")
        }
    }
    suspend fun farm_bit() = coroutineScope{
            for (i in 1..repeat){
            var x = Random.nextInt(0, 20000)
            println("За этот день вы заработали примерно...")
            println("$x рублей")
            summ+=x;
            delay(2000L)
            }
            delay(1000L)
            println("Заработали вы за всё время: $summ")
            delay(1000L)
            println("Ферма закончила работу!\nВам пришли счета за электричество в размере ${repeat*10000}р.")
            delay(1000L)
            println("Проводим оплату налогов...")
            delay(1500L)
            if (summ < repeat*10000){
                println("Вы ушли в минус, вашу майнинг ферму забрало правительство, а вас сослали в тайгу")
            }
            else{
                println("Ура! у вас получилось уйти в плюс (${summ-repeat*10000})")
                delay(1400L)
                println("Недолго думаю вы уехали на Мальдивы")
            }
    }
}
