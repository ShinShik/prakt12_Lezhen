import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

class GithubRepository {
    private val users = mutableMapOf<String, MutableList<String>>()

    suspend fun Start() {
        println(
            "Что вы хотите сделать?\n" +
                    "Добавить пользователя(1);\n" +
                    "Добавить репозиторий пользовтелю(2);\n" +
                    "Вывести всех пользователей и их репозиории(3)"
        )
        var act = readln()
        if (act == "1") {
            addUser()
            Start()
        } else if (act == "2") {
            addRepositoryToUser()
            Start()
        } else if (act == "3") {
            displayAllUsers()
            Start()
        } else {
            println("Введено некорректное значение")
            Start()
        }
    }

    fun addUser() {
        println("Введите имя пользователя:")
        val userName = readLine() ?: ""
        users[userName] = mutableListOf()
    }

    fun addRepositoryToUser() {
        println("Введите имя пользователя:")
        val userName = readLine() ?: ""
        if (users.containsKey(userName)) {
            println("Введите имя репозитория:")
            val repositoryName = readLine() ?: ""
            println("Введите парол для репозитория:")
            val password = readLine() ?: ""

            users[userName]?.add(repositoryName)
            println("Репозиторий $repositoryName добавлен к пользователю $userName")
        } else {
            println("Пользователь $userName не найден")
        }
    }

    suspend fun displayAllUsers() {
        println("Вывод всех пользователей...")
        delay(2000) // Simulating delay with coroutines

        for ((user, repositories) in users) {
            println("Пользователь: $user, Кол-во Репозиториев: ${repositories.size}")
        }
    }
}
