import kotlin.coroutines.*
suspend fun main() {
    val n = num1()
    n.start()
}
