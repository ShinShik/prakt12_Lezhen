import kotlin.coroutines.*
suspend fun main() {
    println("Какое задание вы хотите посмотреть?")
    val quest = readln()
    if (quest == "1"){
        val n = num1()
        n.start()
    }
    if (quest == "2"){
        val n = GithubRepository()
        n.Start()
    }

}
